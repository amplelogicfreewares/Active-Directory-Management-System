﻿
function LogInValidation(domainId, unameId, pwdId) {
    var domain = document.getElementById(domainId).value;
    var userName = document.getElementById(unameId).value.trim();
    var password = document.getElementById(pwdId).value;
    if (domain && userName && password) {
        return true;
    }
    else {
        alert('Please enter all the fields');
        return false;
    }
}


//This function clears the LogIn fields.
function LoginClear(domainId, unameId, pwdId) {
//    document.getElementById(domainId).value = "";
//    document.getElementById(unameId).value = "";
    document.getElementById(pwdId).value = "";
}


//This function gives the alert with supplied input.
function AlertMsg(msg) {
    alert(msg);
}


//This function unchecks the all checked checkboxes in the Questions div.
function clearSelection(gridId) {
    GridData = document.getElementById(gridId);
    if (GridData != null) {
        for (var i = 0; i <= GridData.rows.length - 1; i++) {
            for (var j = 0; j <= GridData.rows[i].cells.length - 1; j++) {
                for (var k = 0; k <= GridData.rows[i].cells[j].children.length - 1; k++) {
                    if (GridData.rows[i].cells[j].children[0].children[0].type == "checkbox") {
                        GridData.rows[i].cells[j].children[0].children[0].checked = false;
                    }
                }
            }
        }
    }
}


//This function changes the back color of the selected question in the grid.
function cbChecked(checkbox) {
    cb = document.getElementById(checkbox.id);
    if (cb.checked) {
        cb.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
    }
    else {
        cb.parentElement.style.backgroundColor = 'white';
        cb.parentElement.parentElement.style.backgroundColor = 'white';
    }
}



//This function erturns TRUE if the selected questions count is 5 ELSE returns FALSE.
function QuestionCount(gridId, Quecount) {
    GridData = document.getElementById(gridId);
    var count = 0;
    if (GridData != null) {
        for (var i = 0; i <= GridData.rows.length - 1; i++) {
            for (var j = 0; j <= GridData.rows[i].cells.length - 1; j++) {
                for (var k = 0; k <= GridData.rows[i].cells[j].children.length - 1; k++) {
                    if (GridData.rows[i].cells[j].children[0].children[0].type == "checkbox") {
                        if (GridData.rows[i].cells[j].children[0].children[0].checked) {
                            ++count;
                        }
                    }
                }
            }
        }
    }

    //Checking the count
    if (count == Quecount) {
        return true;
    }
    else {
        msg = "Please select " + Quecount + " questions";
        alert(msg);
        return false;
    }
}



//This function clears the text in the textboxes in thw selected questions div.
function ClearAnswers(gridId) {
    GridData = document.getElementById(gridId);
    if (GridData != null) {
        for (var i = 0; i <= GridData.rows.length - 1; i++) {
            for (var j = 0; j <= GridData.rows[i].cells.length - 1; j++) {
                for (var k = 0; k <= GridData.rows[i].cells[j].children[0].children.length - 1; k++) {
                    if (GridData.rows[i].cells[j].children[0].children[k].children[0].type == "text") {
                        GridData.rows[i].cells[j].children[0].children[k].children[0].value = "";
                    }
                }
            }
        }
    }
}


//This function gives the back color for the checkboxes when user clicks back.
function GridCheckBoxBackColor(gridId) {
    GridData = document.getElementById(gridId);
    if (GridData != null) {
        for (var i = 0; i <= GridData.rows.length - 1; i++) {
            for (var j = 0; j <= GridData.rows[i].cells.length - 1; j++) {
                for (var k = 0; k <= GridData.rows[i].cells[j].children.length - 1; k++) {
                    if (GridData.rows[i].cells[j].children[0].children[0].type == "checkbox") {
                        if (GridData.rows[i].cells[j].children[0].children[0].checked) {
                            GridData.rows[i].cells[j].children[0].children[0].parentElement.style.backgroundColor = 'cornflowerblue';
                            GridData.rows[i].cells[j].children[0].children[0].parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
                        }
                    }
                }
            }
        }
    }
}



