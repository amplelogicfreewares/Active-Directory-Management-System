﻿

//This Function clears the inputted answers in the textboxes.
function ClearAnswers(gridId) {
    GridData = document.getElementById(gridId);
    if (GridData != null) {
        for (var i = 0; i <= GridData.rows.length - 1; i++) {
            for (var j = 0; j <= GridData.rows[i].cells.length - 1; j++) {
                for (var k = 0; k <= GridData.rows[i].cells[j].children[0].children.length - 1; k++) {
                    if (GridData.rows[i].cells[j].children[1].children[0].type == "text") {
                        GridData.rows[i].cells[j].children[1].children[0].value = "";
                    }
                }
            }
        }
    }
}


//This Function validates the inputted answers.
function ValidateAnswers(gridId) {
    GridData = document.getElementById(gridId);
    if (GridData != null) {
        for (var i = 0; i <= GridData.rows.length - 1; i++) {
            for (var j = 0; j <= GridData.rows[i].cells.length - 1; j++) {
                for (var k = 0; k <= GridData.rows[i].cells[j].children[0].children.length - 1; k++) {
                    if (GridData.rows[i].cells[j].children[1].children[0].type == "text") {
                        if (GridData.rows[i].cells[j].children[1].children[0].value == "") {
                            alert('Answers can not be empty.');
                            return false;
                        }
                    }
                }
            }
        }
    }
    return true;
}