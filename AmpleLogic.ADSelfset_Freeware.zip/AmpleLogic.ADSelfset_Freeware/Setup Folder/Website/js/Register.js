﻿function cbMouseOut(cb) {
    if (cb.parentElement.style.backgroundColor != "cornflowerblue" && cb.style.backgroundColor != "cornflowerblue") {
        cb.parentElement.parentElement.style.backgroundColor = 'white';
        cb.parentElement.style.backgroundColor = 'white';
        cb.style.backgroundColor = 'white';
    }
    else {
        cb.parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.style.backgroundColor = 'cornflowerblue';
    }
}
function cbMouseOver(cb) {
    if (!cb.checked) {
        cb.parentElement.style.backgroundColor = 'green';
    }
}
function GridCheckBoxBackColor() {
    var length = document.getElementById('ContentPlaceHolder1_gvQuestions').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        if (document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).checked) {
            document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).parentElement.style.backgroundColor = 'cornflowerblue';
        }
    }
}
function alphbetvalidation() {
    testresult = true;
    gvRowsCount = document.getElementById('ContentPlaceHolder1_gvSelctdQue').rows.length - 1;
    for (var i = 0; i <= gvRowsCount; i++) {
        var obj = document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + i)
        var x = obj.value
        var anum = /^\w+$/
        //     /^[a-zA-Z ]+$---Only alphabets.
        ///    ^\w+$/----------alphabets and numerics(AlphaNumeric).

        if (anum.test(x) || obj.value.length == 0) {

        }
        else {
            alert("Please enter alphanumerics only!")

            //                    obj.value = "";
            //                    obj.focus()
            testresult = false;
            break;
        }
    }
    return (testresult)
}

function AlertMsg(msg) {
    window.alert(msg);
}
function cbChecked(checkbox) {
    cb = document.getElementById(checkbox.id);
    if (cb.checked) {

        cb.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
    }
    else {
        cb.parentElement.style.backgroundColor = 'white';
    }
}
function LogInValidation() {
    try {
        var elemDomain = document.getElementById('<% =txtDomainName.ClientID %>').value;
        var eleUname = document.getElementById("<% =txtUserName.ClientID %>").value;
        var elePwd = document.getElementById("<% =txtPassword.ClientID %>").value;
        if (!!elemDomain && !!eleUname && !!elePwd) {
            return true;
        }
        else {
            window.alert('Please enter all the fields');
            return false;
        }
    } catch (e) {
        window.alert(e.Message);
    }
}
function RegdSucsfly() {
    window.alert('Registration has completed successfully.');
}
function LogInClear() {
    try {
        document.getElementById("<% =txtDomainName.ClientID %>").value = "";
        document.getElementById("<% =txtUserName.ClientID %>").value = "";
        document.getElementById("<% =txtPassword.ClientID %>").value = "";
    } catch (e) {
        window.alert(e.Message);
    }
}
function AlertCredentials() {
    window.alert("Please check the credentials that you have supplied.");
}
function AlertRegistered() {
    window.alert("The userId has already registerd.");
}
function clearSelection() {
    var length = document.getElementById('ContentPlaceHolder1_gvQuestions').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).checked = false;
    }
}
function Questionsdiv() {
    var elem = document.getElementById("Step2");
    elem.src = "../Images/Step1Active.png";
    //            document.getElementById("=Step1.ClientID %>").src = "../Images/Step1Deactive.png";
    //            document.getElementById("=Step3.ClientID %>").src = "../Images/Step1Deactive.png";
}
function ClearAnswers() {
    var length = document.getElementById('ContentPlaceHolder1_gvSelctdQue').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + index).value = "";
    }
}
function Back() {
    document.getElementById('<%=imgStep2.ClientID %>').src = "../Images/Step1Active.png"
    document.getElementById('<%=imgStep3.ClientID %>').src = "../Images/Step1Deactive.png"
    document.getElementById('<%=QuestionsDiv.ClientID %>').style.display = 'block';
    document.getElementById('<%=SeldQueDiv.ClientID %>').style.display = 'none';
}
function AnswersValidation(flag) {
    try {
        if (flag) {
            var gv = document.getElementById('ContentPlaceHolder1_gvSelctdQue');
            var length = gv.rows.length - 1;
            for (var index = 0; index <= length; index++) {
                var txt = document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + index);
                if (!!txt.value) {

                }
                else {
                    window.alert("Please answer all the questions");
                    return false;
                }
            }
            return true;
        }
        else {
            return false;
        }
    } catch (ex) {
        throw ex;
    }
}
function QuestionCount() {
    try {
        var count = 0;
        var gv = document.getElementById('ContentPlaceHolder1_gvQuestions');
        var length = gv.rows.length - 1;
        for (var index = 0; index <= length; index++) {
            var cb = document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index);
            if (cb.checked) {
                ++count;
            }
        }
        if (count == 3) {
            return true;
        }
        else if (count > 3) {
            window.alert("You can select a maximum of three question only.");
            return false;
        }
        else if (count < 3) {
            window.alert("You should select a minimum of three questions.");
            return false;
        }
    } catch (e) {
        window.alert(e.Message);
    }
}