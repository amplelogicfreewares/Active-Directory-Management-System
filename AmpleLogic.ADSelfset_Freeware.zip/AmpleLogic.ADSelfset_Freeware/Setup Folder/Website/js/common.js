﻿function numbersOnly() {

  var e = event;
  var unicode = e.charCode ? e.charCode : e.keyCode;
  if (unicode != 8) {
    //if the key isn't the backspace key (which we should allow)
    if (unicode == 13 || unicode == 32) //if the key is enter key(13) or Space bar key(32)
    {
      return false;
    }
    if (unicode < 48 || unicode > 57) { //if not a number
      alert('Please enter Numbersonly');
      return false; //disable key press
    }

  }
}
function validatenumber() {
  var e = event;
  var unicode = e.charCode ? e.charCode : e.keyCode;
  if (unicode != 8) {
    //if the key isn't the backspace key (which we should allow)
    if (unicode == 13 || unicode == 32 || unicode == 46)  //if the key is enter key(13) or Space bar key(32)
    {
      return false;
    }
    if (unicode < 48 || unicode > 57) { //if not a number
      if (unicode != 46) {
        alert('Please enter Numbers only');
        return false //disable key press
      }
    }
  }
}
function initializeCalendar(txtBox, img) {
  var commonpartOfId = 'ctl00_ContentPlaceHolder1_';
  var txtBoxId = commonpartOfId + txtBox;

  Calendar.setup({
    inputField: txtBoxId, //"ctl00_ContentPlaceHolder1_StartDate",     // id of the input field
    ifFormat: "%d/%m/%Y",      // format of the input field
    button: img,  // trigger for the calendar (button ID)
    align: "bR",       // alignment (defaults to "Bl")
    singleClick: true
  });
}
function initializeusrControlCalendar(txtBox, img) {

  // var commonpartOfId = 'ctl00_ContentPlaceHolder1_';
  var txtBoxId = txtBox;

  Calendar.setup({
    inputField: txtBoxId, //"ctl00_ContentPlaceHolder1_StartDate",     // id of the input field
    ifFormat: "%d/%m/%Y",      // format of the input field
    button: img,  // trigger for the calendar (button ID)
    align: "bR",       // alignment (defaults to "Bl")
    singleClick: true
  });
}
function ValidateNegetiveNumbers(e) {
  try {
    var keycode = e.keyCode || e.which;
    if (keycode != 8 && keycode != 45 && !(keycode >= 48 && keycode <= 57))
      e.preventDefault ? e.preventDefault() : e.returnValue = false;
  }
  catch (err) {
    alert(err.description);
  }
}
function initializeCalendarRange(txtBox, img) {
  var commonpartOfId = 'ctl00_ContentPlaceHolder1_';
  var txtBoxId = commonpartOfId + txtBox;

  Calendar.setup({
    inputField: txtBoxId, //"ctl00_ContentPlaceHolder1_StartDate",     // id of the input field
    ifFormat: "%d/%m/%Y", // format of the input field
    range: [2000, 2099],
    button: img,  // trigger for the calendar (button ID)
    align: "bR",       // alignment (defaults to "Bl")
    singleClick: true
  });
}
function initializeusrCntrlCalendarRange(txtBox, img) {
  // var commonpartOfId = 'ctl00_ContentPlaceHolder1_';
  var txtBoxId = txtBox;

  Calendar.setup({
    inputField: txtBoxId, //"ctl00_ContentPlaceHolder1_StartDate",     // id of the input field
    ifFormat: "%d/%m/%Y", // format of the input field
    range: [2000, 2099],
    button: img,  // trigger for the calendar (button ID)
    align: "bR",       // alignment (defaults to "Bl")
    singleClick: true
  });
}
function initializeCalendarControl(txtBox, img) {
  var txtBoxId = txtBox;
  Calendar.setup({
    inputField: txtBoxId, //"ctl00_ContentPlaceHolder1_StartDate",     // id of the input field
    ifFormat: "%d/%m/%Y",      // format of the input field
    button: img,  // trigger for the calendar (button ID)
    align: "bR",       // alignment (defaults to "Bl")
    singleClick: true
  });
  return false;
}
function ImgClick() {
  MM_openBrWindow('calendar.htm', 'cal', 'width=170,height=184');
}
function MM_openBrWindow(theURL, winName, features) {
  window.open(theURL, winName, features);
}
function detectBrowser() {

  var browser = navigator.appName;
  var b_version = navigator.appVersion;
  var version = parseFloat(b_version);
  if ((browser != "Microsoft Internet Explorer")) {
    //alert("Please use Internet Explorer Version 5 onwards to browse!");
    //window.open("RedirectPage.aspx","PageRedirection","_blank");          
    document.location.href = "RedirectPage.aspx?crossBrowser=1&browser=" + browser;
  }

}
function LockTextBox() {
  return false //disable key press
}
function validatePOPrice(obj) { // Remove dot if last character
  var x = obj.value;
  var retVal = true;
  var code = (event.which) ? event.which : event.keyCode;
  //alert(obj);
  if (obj.value.indexOf(".") == obj.value.length - 1) {
    obj.value = obj.value.substring(0, obj.value.length - 1)
  }
  if (obj.value != '') {
    var noOfdecimals;
    noOfdecimals = obj.value.split('.');
    if (noOfdecimals[1] != null) {
      if (noOfdecimals[1].length > 2) {
        obj.focus();
        alert('Please enter price upto two decimals');

        retVal = false;
      }
      else
        retVal = true;

    }
    var count;
    count = obj.value.split('.').length - 1;
    if (count > 1) {
      //obj.focus();
      alert('Price should be in correct format');
      obj.focus();
      retVal = false;
    }

  }
  return retVal;
}
function ChkAmountExceeded(amount) {
  if (parseFloat(amount) != null && parseFloat(amount) > 999999999.99) {
    alert("item total price is too high to accommodate");
    return false;
  }
  else
    return true;
}
function round_number(rnum, rlength) {

  // Arguments: number to round, number of decimal places
  var newnumber = Math.round(rnum * Math.pow(10, rlength)) / Math.pow(10, rlength);
  // Output the result to the form field (change for your purposes)
  return newnumber;
}

function CalculatePOLineTotal(txtQty, txtPrice, lblItemTotal, hdnPreviousAmt, lblTotalAmount, chkVoid) {
  var var_txtQty = document.getElementById(txtQty).value == '' ? 0 : document.getElementById(txtQty).value;
  var var_txtPrice = document.getElementById(txtPrice).value == '' ? 0 : document.getElementById(txtPrice).value;
  var var_lblItemTotal = document.getElementById(lblItemTotal).value == '' ? 0 : document.getElementById(lblItemTotal).value;
  var var_txtPOTotal = document.getElementById(lblTotalAmount).innerText == '' ? 0 : document.getElementById(lblTotalAmount).innerText;
  var var_hdPrevtotal = document.getElementById(hdnPreviousAmt).value == '' ? 0 : document.getElementById(hdnPreviousAmt).value;
  if (validatePOPrice(document.getElementById(txtPrice))) {
    var_txtPrice = document.getElementById(txtPrice).value == '' ? 0 : document.getElementById(txtPrice).value;
    if (ChkAmountExceeded(var_txtQty * var_txtPrice)) {
      var lineTotal = Number(var_txtQty) * parseFloat(var_txtPrice);
      document.getElementById(lblItemTotal).innerText = round_number(lineTotal, 2).toString().indexOf(".", 0) > 0 ? round_number(lineTotal, 2) : round_number(lineTotal, 2) + '.00';
      document.getElementById(lblTotalAmount).innerText = round_number(((parseFloat(var_txtPOTotal) - parseFloat(var_hdPrevtotal)) + lineTotal), 2);
      document.getElementById(hdnPreviousAmt).value = document.getElementById(lblItemTotal).innerText;
      if (document.getElementById(chkVoid).checked) {
        document.getElementById(lblTotalAmount).value = round_number(((parseFloat(var_txtPOTotal) - parseFloat(var_hdPrevtotal)) + lineTotal), 2);
        document.getElementById(hdnPreviousAmt).value = document.getElementById(lblItemTotal).innerText;
      }
    }
    else {
      document.getElementById(txtQty).value = '';
      document.getElementById(txtPrice).value = '';
      document.getElementById(lblTotalAmount).innerText = round_number((var_txtPOTotal - parseFloat(document.getElementById(lblItemTotal).innerText)), 2);
      document.getElementById(lblItemTotal).innerText = '';
    }
  }
}
function calcAmount(txtQty, txtPrice, hdnPreviousAmt, lblTotalAmount, chkVoid) {
  var var_txtPOTotal = document.getElementById(lblTotalAmount).innerText == '' ? 0 : document.getElementById(lblTotalAmount).innerText;
  var var_hdPrevtotal = document.getElementById(hdnPreviousAmt).value == '' ? 0 : document.getElementById(hdnPreviousAmt).value;
  if (document.getElementById(chkVoid).checked) {
    document.getElementById(lblTotalAmount).innerText = round_number(((parseFloat(var_txtPOTotal) - parseFloat(var_hdPrevtotal))), 2);
  }
  else {
    var res = parseFloat(var_txtPOTotal) + parseFloat(var_hdPrevtotal);
    document.getElementById(lblTotalAmount).innerText = round_number(res, 2);
  }
}
function ValidatePrices(str) {
  try {
    var keycode = window.event.keyCode;
    if (!(keycode == 46 || (keycode >= 48 && keycode <= 57)))
      window.event.returnValue = false;
  }
  catch (err) {
    alert(err.description);
  }
}
function ValidateDotEntry(obj) {
  try {
    var x = obj.value.indexOf(".");
    if (obj.value.substring(x + 1, obj.value.length).indexOf(".") > 0) {
      alert('Please enter the price in the correct format');
      return false;
    }
    else {
      return true;
    }
  }
  catch (err) {
    alert(err.description);
  }

}
function validateBackSpaceEntry(str) {
  try {
    var keycode = window.event.keyCode;
    if (keycode == 8)
      window.event.returnValue = false;
    return false;
  }
  catch (err) {
    alert(err.description);
  }
}
function ValidateNumerics(e) {
  try {
    var keycode = e.keyCode || e.which;
    if (keycode != 8 && !(keycode >= 48 && keycode <= 57))
      e.preventDefault ? e.preventDefault() : e.returnValue = false;
  }
  catch (err) {
    alert(err.description);
  }
}

//Client feedback implementation
//Compares two dates
//if first date is greater than second date then returns false   
function CompareDates(date1, date2) {
  var blnEarlier = true;
  //    var vDate1 = new Date(date1);
  //    var vDate2 = new Date(date2);

  //    if (vDate1.getFullYear() < vDate2.getFullYear())	//compare year
  //        blnEarlier = true;
  //    else if (vDate1.getFullYear() > vDate2.getFullYear())
  //        blnEarlier = false;
  //    else
  //        if (vDate1.getMonth() < vDate2.getMonth())	//compare month
  //        blnEarlier = true;
  //    else if (vDate1.getMonth() > vDate2.getMonth())
  //        blnEarlier = false;
  //    else
  //        if (vDate1.getDate() < vDate2.getDate())	//compare day
  //        blnEarlier = true;
  //    else
  //        blnEarlier = false;

  //    //if two dates are same then returns true
  //    if (vDate1.getFullYear() == vDate2.getFullYear() && vDate1.getMonth() == vDate2.getMonth() && vDate1.getDate() == vDate2.getDate()) {
  //        blnEarlier = true;
  //    }

  var vD1_Year = date1.substr(6, 4);
  var vD2_Year = date2.substr(6, 4);

  var vD1_Month = date1.substr(3, 2);
  var vD2_Month = date2.substr(3, 2);

  var vD1_Day = date1.substr(0, 2);
  var vD2_Day = date2.substr(0, 2);

  if (vD1_Year < vD2_Year)	//compare year
    blnEarlier = true;
  else if (vD1_Year > vD2_Year)
    blnEarlier = false;
  else
    if (vD1_Month < vD2_Month)	//compare month
      blnEarlier = true;
    else if (vD1_Month > vD2_Month)
      blnEarlier = false;
    else
      if (vD1_Day < vD2_Day)	//compare day
        blnEarlier = true;
      else
        blnEarlier = false;

  //if two dates are same then returns true
  if (vD1_Year == vD2_Year && vD1_Month == vD2_Month && vD1_Day == vD2_Day) {
    blnEarlier = true;
  }


  return (blnEarlier);
}
function ConfirmdeleteContWithtxt(txt) {
  if (confirm(txt))
    return true;
  else
    return false;
}
function numericvalidation() {

  var obj = event.srcElement;
  var x = obj.value
  var anum = /(^\d+$)|(^\d+\.\d+$)/


  if (anum.test(x) || obj.value.length == 0) {
    testresult = true

  }
  else {
    alert("Please Enter numbers only!")

    obj.value = "";
    obj.focus()
    testresult = false
  }
  return (testresult)
}
function alphbetvalidation() {

  var obj = event.srcElement;
  var x = obj.value
  var anum = /^[a-zA-Z ]+$/


  if (anum.test(x) || obj.value.length == 0) {
    testresult = true

  }
  else {
    alert("Please enter alphabets only!")

    obj.value = "";
    obj.focus()
    testresult = false
  }
  return (testresult)
}
function alphanumericvalidation() {

  var obj = event.srcElement;
  var x = obj.value
  var anum = /^[0-9a-zA-Z ]+$/
  if (anum.test(x) || obj.value.length == 0) {
    testresult = true
  }
  else {
    alert("Please enter alphanumeric only!")

    obj.value = "";
    obj.focus()
    testresult = false
  }
  return (testresult)
}
function MailAddressValidation() {

  var obj = event.srcElement;
  var x = obj.value
  var anum = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/

  if (anum.test(x) || obj.value.length == 0) {
    testresult = true
  }
  else {
    alert("Please enter valid Mail Address!")

    obj.value = "";
    obj.focus()
    testresult = false
  }
  return (testresult)
}