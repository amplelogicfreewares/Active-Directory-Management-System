﻿function pageCover(ID,ID2,status)
    {
        
        
      
        
        var winWidth = 0, winHeight = 0;
      if( typeof( window.innerWidth ) == 'number' ) {
        //Non-IE
        winWidth = window.innerWidth;
        winHeight = window.innerHeight;
      } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
        //IE 6+ in 'standards compliant mode'
        winWidth = document.documentElement.clientWidth;
        winHeight = document.documentElement.clientHeight;
      } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
        //IE 4 compatible
        winWidth = document.body.clientWidth;
        winHeight = document.body.clientHeight;
      }
      

        var dimension = getScrollXY();
        
      
        document.getElementById(ID).style.width = winWidth + dimension[0];
        document.getElementById(ID).style.height = winHeight + dimension[1];
        
        if(status == true)
        {
            document.getElementById(ID).className = 'fade';               
            document.getElementById(ID2).className = 'window';   
            
            
            
        }
        else
        {
            document.getElementById(ID).className = 'hide';   
            document.getElementById(ID2).className = 'hide';   
            
        }
        
        
        
        
    }
    
    
    function getScrollXY()     
    /*-----------------------------------------------------------------------------------
    Precondition: None.
    Postcondition: Return the offset for x and y width.
    URL: http://www.howtocreate.co.uk/tutorials/javascript/browserwindow
    -----------------------------------------------------------------------------------*/
    {
      var scrOfX = 0, scrOfY = 0;
      if( typeof( window.pageYOffset ) == 'number' ) {
        //Netscape compliant
        scrOfY = window.pageYOffset;
        scrOfX = window.pageXOffset;
      } else if( document.body && ( document.body.scrollLeft || document.body.scrollTop ) ) {
        //DOM compliant
        scrOfY = document.body.scrollTop;
        scrOfX = document.body.scrollLeft;
      } else if( document.documentElement && ( document.documentElement.scrollLeft || document.documentElement.scrollTop ) ) {
        //IE6 standards compliant mode
        scrOfY = document.documentElement.scrollTop;
        scrOfX = document.documentElement.scrollLeft;
  }
  return [ scrOfX, scrOfY ];
}

    function redirect(URL)
    /*------------------------------------------------------------------------
    Precondition: Receives the URL to redirect to.
    Postcondition: Redirect to the specify URL.
    ------------------------------------------------------------------------*/
    {
        
        location.replace(URL);
    }
    
    
      function getDropDownListVal(ID)
    /*------------------------------------------------------------------------
    Precondition: Receives ID of the dropdownlist.
    Postcondition: Returns the selected dropdownlist value.
    ------------------------------------------------------------------------*/
    {
        
        var obj = document.getElementById(ID);        
        return obj.options[obj.selectedIndex].value
    }
    
        function matchDropDownListVal(ID,match)
    /*------------------------------------------------------------------------
    Precondition: Receives ID of the dropdownlist and the desired value.
    Postcondition: Match the selected dropdownlist value.
    ------------------------------------------------------------------------*/
    {
        
        var obj = document.getElementById(ID);        
        var size = obj.length;
        
        for(d = 0; d < size; d++)
        {
            if(obj.options[d].value == match)
                return d;
        }
        
        
        return 0;
    }
    
    
    
    //-------------------------------------------------------------------
    //Old Code
    //-------------------------------------------------------------------
    //function saveUserInput(TblID,inID,countID)
     /*------------------------------------------------------------------
    Precondition: Receives the TableID, input field ID, and the 
    hidden field for totl count records.
    Postcondition: Write the value from the TableID received into the 
    hidden variables by using the ID's received.
    ------------------------------------------------------------------*/
    /*
    {
        var ins = $(inID);
        var sb = new Array();
        var count = getTableRowNo(TblID);        
        var err = false;
        for(var c = 1; c < count;c++)
        {        
            
            for(var d= 1; d < 8;d++)        
            {
                var obj = $(rPrefix+c+d);
                
                if(obj != null)
                    sb[sb.length] = obj.value+delimiter1;
                else
                {
                
                    
                    for(u=1; u<8;u++)
                    {
                        sb[sb.length] = delimiter1;
                    }
                   
                    err = true;
                    break;
                 }   
                        
                
            }
            if(err == false)
                sb[sb.length] = delimiter2;
            err = false;
        }
        
        ins.value = sb.join('');
        alert("Before Input is: " + ins.value);  //DEBUGGING.
        
        ins.value = replaceSpecialChar(ins.value);
        alert("---> After Input is: " + ins.value);  //DEBUGGING.
        
        //Custom Code.
        var input = $$('input');
        for(var e = 0; e < input.length;e++)
        {
            if( (input[e].type=='text') && (input[e].type=='hidden'))
                replaceSpecialChar(input[e].value);
        }
        
        $(countID).value = count;
    }
    */
    
    
    function isDigit(value)
    {		
        var anum=/(^\d+$)|(^\d+\.\d+$)/		
        if (anum.test(value))			
            return true;		
        return false;    
    }
    
     function isInteger(ID)
    /*------------------------------------------------------------------
    Precondition: Receives the ID of the object.
    Postcondition: Determines if the value is an integer or not.
    ------------------------------------------------------------------*/
    {
        var obj = document.getElementById(ID);
        
        
        if(parseInt(obj.value,10)==obj.value)
        {   
            return true;
        }
            
        return false;
        
    }
    
    function Redirect(url)
    {
        //alert(url); //DEBUG.
        window.location=url;
    }
    function winAdjust(parentID, childID) {

        var p = $(parentID);

        if (p.style.display != "none") {
            //alert('win' + p);          
            pageCover(parentID, childID, true);
        }
    }