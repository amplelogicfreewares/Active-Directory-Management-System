﻿/* 
---------------------------------------------------------------------------------------
Additional Information
---------------------------------------------------------------------------------------
Get XML Count...
URL: http://geekswithblogs.net/workdog/archive/2006/08/17/88334.aspx
---------------------------------------------------------------------------------------
*/


 //if (!window.ActiveXObject)  //Not IE.
 
 
{   
        function selectNodes(obj,sXPath)
        /*------------------------------------------------------------------------                        
        Resource: http://www.wrox.com/WileyCDA/Section/XPath-Support-in-Browsers-Page-2.id-291861.html
        NOTE: Previous Example:            
        
        Element.prototype.selectNodes = function(sXPath)
        Element.extend.selectNodes = function(sXPath) 
        
        However, I cannot get the lines above to work as added function to the 
        element.
        --------------------------------------------------------------------------
        Precondition: Receives the xml object and the xpath.
        Postcondition: Returns the selected single nodes.
        ------------------------------------------------------------------------*/
        {   
        
            var oEvaluator = new XPathEvaluator();
            //var oResult = oEvaluator.evaluate(sXPath, this, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
            var oResult = oEvaluator.evaluate(sXPath, obj, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
            var aNodes = new Array();

            if (oResult != null) 
            {
                var oElement = oResult.iterateNext();

                while(oElement) 
                {
                    aNodes.push(oElement);
                    oElement = oResult.iterateNext();
                }

            }
            return aNodes;
        }
    
   
   
    
        function selectSingleNode(obj,sXPath) 
        /*------------------------------------------------------------------------                        
        Resource: http://www.wrox.com/WileyCDA/Section/XPath-Support-in-Browsers-Page-2.id-291861.html
        NOTE: Previous Example:            
        
        Element.prototype.selectSingleNode = function(sXPath) 
        Element.extend.selectSingleNode = function(sXPath) 
        
        However, I cannot get the lines above to work as added function to the 
        element.
        --------------------------------------------------------------------------
        Precondition: Receives the xml object and the xpath.
        Postcondition: Returns the selected single nodes.
        ------------------------------------------------------------------------*/
        {

            var oEvaluator = new XPathEvaluator();
            
            // FIRST_ORDERED_NODE_TYPE returns the first match to the xpath.
            //var oResult = oEvaluator.evaluate(sXPath, this, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
            var oResult = oEvaluator.evaluate(sXPath, obj, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);

            if (oResult != null) 
            {
                return oResult.singleNodeValue;
            } 
            else 
            {
                return null;
            }

        }
    
} 