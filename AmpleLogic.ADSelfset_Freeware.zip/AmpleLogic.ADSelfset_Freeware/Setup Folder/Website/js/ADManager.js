﻿function cbMouseOut(cb) {
    if (cb.parentElement.style.backgroundColor != "cornflowerblue" && cb.style.backgroundColor != "cornflowerblue") {
        cb.parentElement.parentElement.style.backgroundColor = 'white';
        cb.parentElement.style.backgroundColor = 'white';
        cb.style.backgroundColor = 'white';
    }
    else {
        cb.parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.style.backgroundColor = 'cornflowerblue';
    }
}
function cbMouseOver(cb) {
    if (!cb.checked) {
        cb.parentElement.style.backgroundColor = 'green';
    }
}
function GridCheckBoxBackColor() {
    var length = document.getElementById('ContentPlaceHolder1_gvQuestions').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        if (document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).checked) {
            document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).parentElement.style.backgroundColor = 'cornflowerblue';
        }
    }
}
function alphbetvalidation() {
//2
    testresult = true;
    gvRowsCount = document.getElementById('ContentPlaceHolder1_gvSelctdQue').rows.length - 1;
    for (var i = 0; i <= gvRowsCount; i++) {
        var obj = document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + i)
        var x = obj.value
        var anum = /^\w+$/
        //     /^[a-zA-Z ]+$---Only alphabets.
        ///    ^\w+$/----------alphabets and numerics(AlphaNumeric).

        if (anum.test(x) || obj.value.length == 0) {

        }
        else {
            alert("Please enter alphanumerics only!")

            //                    obj.value = "";
            //                    obj.focus()
            testresult = false;
            break;
        }
    }
    return (testresult)
}

function AlertMsg(msg) {
    window.alert(msg);
}
function cbChecked(checkbox) {
    cb = document.getElementById(checkbox.id);
    if (cb.checked) {

        cb.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
    }
    else {
        cb.parentElement.style.backgroundColor = 'white';
    }
}
function LogInValidation(txtDomainName, txtUserName, txtPassword) {
    try {
        var elemDomain = document.getElementById(txtDomainName).value;
        var eleUname = document.getElementById(txtUserName).value;
        var elePwd = document.getElementById(txtPassword).value;
        if (!!elemDomain && !!eleUname && !!elePwd) {
            return true;
        }
        else {
            window.alert('Please enter all the fields');
            return false;
        }
    } catch (e) {
        window.alert(e.Message);
    }
}
function RegdSucsfly() {
    window.alert('Registration has completed successfully.');
}
function AlertCredentials() {
    window.alert("Please check the credentials that you have supplied.");
}
function AlertRegistered() {
    window.alert("The userId has already registerd.");
}
function clearSelection() {
    var length = document.getElementById('ContentPlaceHolder1_gvQuestions').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).checked = false;
    }
}
function Questionsdiv() {
    var elem = document.getElementById("Step2");
    elem.src = "../Images/Step1Active.png";
    //            document.getElementById("=Step1.ClientID %>").src = "../Images/Step1Deactive.png";
    //            document.getElementById("=Step3.ClientID %>").src = "../Images/Step1Deactive.png";
}
//function ClearAnswers() {
//
//    var length = document.getElementById('ContentPlaceHolder1_gvSelctdQue').rows.length - 1;
//    for (var index = 0; index <= length; index++) {
//        document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + index).value = "";
//    }
//}
function Back() {
    document.getElementById('<%=imgStep2.ClientID %>').src = "../Images/Step1Active.png"
    document.getElementById('<%=imgStep3.ClientID %>').src = "../Images/Step1Deactive.png"
    document.getElementById('<%=QuestionsDiv.ClientID %>').style.display = 'block';
    document.getElementById('<%=SeldQueDiv.ClientID %>').style.display = 'none';
}
function AnswersValidation(flag) {
    try {
        if (flag) {
            var gv = document.getElementById('ContentPlaceHolder1_gvSelctdQue');
            var length = gv.rows.length - 1;
            for (var index = 0; index <= length; index++) {
                var txt = document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + index);
                if (!!txt.value) {

                }
                else {
                    window.alert("Please answer all the questions");
                    return false;
                }
            }
            return true;
        }
        else {
            return false;
        }
    } catch (ex) {
        throw ex;
    }
}
function QuestionCount() {
    try {
        var count = 0;
        var gv = document.getElementById('ContentPlaceHolder1_gvQuestions');
        var length = gv.rows.length - 1;
        for (var index = 0; index <= length; index++) {
            var cb = document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index);
            if (cb.checked) {
                ++count;
            }
        }
        if (count == 3) {
            return true;
        }
        else if (count > 3) {
            window.alert("You can select a maximum of three question only.");
            return false;
        }
        else if (count < 3) {
            window.alert("You should select a minimum of three questions.");
            return false;
        }
    } catch (e) {
        window.alert(e.Message);
    }
}
function closeWindow() {
    window.open('', '_self', '');
    window.close();
}
function GridCheckBoxBackColor() {
    var length = document.getElementById('ContentPlaceHolder1_gvQuestions').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        if (document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).checked) {
            document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).parentElement.style.backgroundColor = 'cornflowerblue';
        }
        else {
            document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).parentElement.style.backgroundColor = 'white';

        }
    }
}
//function alphbetvalidation() {
////1
//    testresult = true;
//    gvRowsCount = document.getElementById('ContentPlaceHolder1_gvSelctdQue').rows.length - 1;
//    for (var i = 0; i <= gvRowsCount; i++) {
//        var obj = document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + i)
//        var x = obj.value
//        var anum = /^\w+$/
//        //     /^[a-zA-Z ]+$---Only alphabets.
//        ///    ^\w+$/----------alphabets and numerics(AlphaNumeric).

//        if (anum.test(x) || obj.value.length == 0) {

//        }
//        else {
//            alert("Please enter alphanumerics only!")

//            //                    obj.value = "";
//            //                    obj.focus()
//            testresult = false;
//            break;
//        }
//    }
//    return (testresult)
//}

function AlertMsg(msg) {
    window.alert(msg);
}
function cbChecked(checkbox) {
    cb = document.getElementById(checkbox.id);
    if (cb.checked) {

        cb.parentElement.style.backgroundColor = 'cornflowerblue';
        cb.parentElement.parentElement.style.backgroundColor = 'cornflowerblue';
    }
    else {
        cb.parentElement.style.backgroundColor = 'white';
        cb.parentElement.parentElement.style.backgroundColor = 'white';
    }
}
function LogInValidation(txtDomainName, txtUserName, txtPassword) {
    try {
        var elemDomain = document.getElementById(txtDomainName).value;
        var eleUname = document.getElementById(txtUserName).value;
        var elePwd = document.getElementById(txtPassword).value;
        if (!!elemDomain && !!eleUname && !!elePwd) {
            return true;
        }
        else {
            window.alert('Please enter all the fields');
            return false;
        }
    } catch (e) {
        window.alert(e.Message);
    }
}
function RegdSucsfly() {
    window.alert('Registration has completed successfully.');
}
function AlertCredentials() {
    window.alert("Please check the credentials that you have supplied.");
}
function AlertRegistered() {
    window.alert("The userId has already registerd.");
}
function clearSelection(gridId) {
    var gv = document.getElementById(gridId);
    var length = gv.rows.length - 1;
    for (var index = 0; index <= length; index++) {
        document.getElementById('ContentPlaceHolder1_gvQuestions_cbQuestion_' + index).checked = false;
    }
}
function Questionsdiv() {
    var elem = document.getElementById("Step2");
    elem.src = "../Images/Step1Active.png";
    //            document.getElementById("=Step1.ClientID %>").src = "../Images/Step1Deactive.png";
    //            document.getElementById("=Step3.ClientID %>").src = "../Images/Step1Deactive.png";
}
function ClearAnswers() {

    var length = document.getElementById('ContentPlaceHolder1_gvSelctdQue').rows.length - 1;
    for (var index = 0; index <= length; index++) {
        document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + index).value = "";
    }
}
function Back() {
    document.getElementById('<%=imgStep2.ClientID %>').src = "../Images/Step1Active.png"
    document.getElementById('<%=imgStep3.ClientID %>').src = "../Images/Step1Deactive.png"
    document.getElementById('<%=QuestionsDiv.ClientID %>').style.display = 'block';
    document.getElementById('<%=SeldQueDiv.ClientID %>').style.display = 'none';
}
function AnswersValidation(flag) {
    try {
        if (flag) {
            var gv = document.getElementById('ContentPlaceHolder1_gvSelctdQue');
            var length = gv.rows.length - 1;
            for (var index = 0; index <= length; index++) {
                var txt = document.getElementById('ContentPlaceHolder1_gvSelctdQue_txtAns_' + index);
                if (!!txt.value) {

                }
                else {
                    window.alert("Please answer all the questions");
                    return false;
                }
            }
            return true;
        }
        else {
            return false;
        }
    }
    catch (ex) {
        throw ex;
    }
}
function SSVA(id) {
}

function LogInClear(domain, uname, pass) {
    if (domain != null) {
        document.getElementById(domain).value = "";
    }
    if (uname != null) {
        document.getElementById(uname).value = "";
    }
    if (pass != null) {
        document.getElementById(pass).value = "";
    }
}
function QuestionCount(gridId) {
    debugger;
    try {
        var count = 0;
        var gv = document.getElementById(gridId);
        var length = gv.rows.length;
        for (var index = 0; index < length; index++) {
            index = index + 2;
            //ctl00_ContentPlaceHolder1_gvQuestions_ctl02_cbQuestion
            if (index > 9) {
                var cb = document.getElementById(gridId + '_ctl' + index + '_cbQuestion');
            }
            else {
                var cb = document.getElementById(gridId + '_ctl0' + index + '_cbQuestion');    
            }
            
            index = index - 2;
            if (cb.checked) {
                ++count;
            }
        }
        if (count == 5) {
            return true;
        }
        else if (count > 5) {
            window.alert("You can select a maximum of five question only.");
            return false;
        }
        else if (count < 5) {
            window.alert("You should select a minimum of five questions.");
            return false;
        }
    } catch (e) {
        window.alert(e.Message);
    }
}


/* ----------- ResetPwd.aspx ---------------- */
function AlertMsg(msg) {
    window.alert(msg);
}
function HomeFieldsValidation() {
//    var domain = document.getElementById('ContentPlaceHolder1_txtDomain').value;
//    var userName = document.getElementById('ContentPlaceHolder1_txtUsername').value; 
//    if ((!domain) && (!userName)) {
//        window.alert("Please enter the Domain and User Name.");
//        return false;
//    }
//    else if (!domain) {
//        window.alert("Please enter the Domain.");
//        return false;
//    }
//    else if (!userName) {
//        window.alert("Please enter the User Name.");
//        return false;
//    }
//    return true;
}

function CloseBrowser() {
    window.alert('Password has been reset successfully.');
    window.close();
}

function ValidateAnswers() {
    var retValue = true;
    var gridView = document.getElementById('<% =gvQuestions.ClientID %>');
    var gvRows = gridView.rows.length - 1;
    for (var index = 0; index <= gvRows; index++) {
        var txtAns = document.getElementById('ContentPlaceHolder1_gvQuestions_txtAnswer_' + index).value;
        if (!txtAns.trim()) {
            window.alert('Please enter answers for all the questions.')
            retValue = false;
            break;
        }
    }
    return retValue;
}
//function ClearAnswers() {
//
//    var gvRows = document.getElementById('<% =gvQuestions.ClientID %>').rows.length - 1;
//    for (var index = 0; index <= gvRows; index++) {
//        document.getElementById('ContentPlaceHolder1_gvQuestions_txtAnswer_' + index).value = "";
//    }
//}
function ClearPasswords() {
    document.getElementById('<%=txtNewPassword.ClientID %>').value = "";
    document.getElementById('<%=txtCnfrmPassword.ClientID %>').value = "";
}
function DisplayReset(flag) {//used to validate the user answers with DB answers.
    var divFlag = true;
    var ActAnswer = "";
    var ActAnswer1 = "";
    if (flag == true) {
        var gvRows = document.getElementById('<% =gvQuestions.ClientID %>').rows.length - 1;
        for (var index = 0; index <= gvRows; index++) {

            var UserAnswer = document.getElementById('ContentPlaceHolder1_gvQuestions_txtAnswer_' + index).value.trim();
            var ByteArrayActAnswer = document.getElementById('ContentPlaceHolder1_gvQuestions_hdnAnswer_' + index).value.trim();
            for (var i = 0; i < ByteArrayActAnswer.length; i++) {
                ActAnswer += String.fromCharCode(parseInt(ByteArrayActAnswer[i], 36));
                ActAnswer1 += String.fromCharCode(ByteArrayActAnswer[i]);
            }
            var ActAnswer = ByteArrayActAnswer.toString();
            if (ActAnswer != UserAnswer) {//If UserAnswers and DbAnswers are same
                divFlag = false;
            }
        }
        if (divFlag == true) {
            document.getElementById('<%=QuesionsDiV.ClientID %>').style.display = "none";
            document.getElementById('<%=ResetDiv.ClientID %>').style.display = "block";
        }
    }
}
function VaildatePasswords() {

    var txtNewPwd = document.getElementById('<%=txtNewPassword.ClientID %>').value;
    var txtCnfrmPwd = document.getElementById('<%=txtCnfrmPassword.ClientID %>').value
    if (txtNewPwd && txtCnfrmPwd) {
        if (txtNewPwd.trim() == txtCnfrmPwd.trim()) {
            if ((txtNewPwd.trim().length >= 9) && (txtNewPwd.trim().match(/\d+/)) && (txtNewPwd.trim().match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/))) {
                return true;
            }
            else {
                window.alert('Password should contain minimum of 9 characters. And it should contain one numeric and one special character like !,@,#,$,%,^,& etc');
                return false;
            }
        }
        else {
            window.alert('Both password fields should match, Please check.');
            return false;
        }
    }
    else {
        window.alert('Password fields should not be empty.');
        return false;
    }
}
function WrongAns(AnsNum) {
    switch (AnsNum) {
        case 1:
            window.alert('The First answer does not match. Please Check.');
            break;
        case 2:
            window.alert('The Second answer does not match. Please Check.');
            break;
        case 3:
            window.alert('The Third answer does not match. Please Check.');
            break;
    }
}
function LogInClear() {
    try {
        document.getElementById("<% =txtDomain.ClientID %>").value = "";
        document.getElementById("<% =txtUsername.ClientID %>").value = "";

    } catch (e) {
        window.alert(e.Message);
    }
}
/* ----------- ResetPwd.aspx ---------------- */