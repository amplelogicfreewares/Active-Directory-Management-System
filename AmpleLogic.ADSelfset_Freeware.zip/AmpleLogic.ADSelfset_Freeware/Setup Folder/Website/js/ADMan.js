﻿/*------Start of Register.aspx ------*/
function LogInClear(txtDomainName, txtUserName, txtPassword) {
    try {        
        //        document.getElementById("txtDomainName").value = "";
        //        document.getElementById("txtUserName").value = "";
        document.getElementById("txtPassword").value = "";
    } catch (e) {
        window.alert(e.Message);
    }
}
/*------End of Register.aspx ------*/

/*------Start of ResolveTickets.aspx ------*/
function ResetPassword(newPassword, confirmPassword, dropDown) {
    try {        
        var ddlValue = document.getElementById(dropDown).value;
        if (ddlValue == '2') {
            var newPassword = document.getElementById(newPassword).value;
            var confirmPassword = document.getElementById(confirmPassword).value;
            if (newPassword && confirmPassword) {
                if (newPassword == confirmPassword) {
                    return true;
                    //                if ((newPassword.trim().length >= 9) && (newPassword.trim().match(/\d+/)) && (newPassword.trim().match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/))) {
                    //                    return true;
                    //                }
                    //                else {
                    //                    window.alert('Password should contain minimum of 9 characters. And it should contain one numeric and one special character like !,@,#,$,%,^,& etc');
                    //                    return false;
                    //                }
                }
                else {
                    window.alert('Both password fields should match, Please check.');
                    return false;
                }
            }
            else {
                window.alert('Password fields should not be empty.');
                return false;
            }
        }
    }
    catch (e) {
        window.alert(e.Message);
        return false;
    }

}


/*------End of ResolveTickets.aspx ------*/

/*-------start of Update Account.aspx-----*/
function ClearAllFields(txtHomeNo, txtMobileNo, txtIpPhone, txtStreet, txtCity, txtState, txtZip) {
    document.getElementById("txtHomeNo").value = "";
    document.getElementById("txtMobileNo").value = "";
    document.getElementById("txtIpPhone").value = "";
    document.getElementById("txtStreet").value = "";
    document.getElementById("txtCity").value = "";
    document.getElementById("txtState").value = "";
    document.getElementById("txtZip").value = "";
}

/*------End of Update Account.aspx ------*/


function RedirectToHome() {
    window.location.href = "Default.aspx?Mode=Reset";
}