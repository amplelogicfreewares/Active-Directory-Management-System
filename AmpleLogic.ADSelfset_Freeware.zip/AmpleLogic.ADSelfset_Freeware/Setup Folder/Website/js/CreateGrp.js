﻿function ValidateGrp() {
   
    var special = "^[a-zA-Z0-9 ? ]+$";
    var grp = document.getElementById('<%=txtGrp.ClientID%>');
    var userName = document.getElementById('<%=txtGrpOwner.ClientID%>');
    var msg = "";
    if (grp.value.trim() == "") {
        msg = msg + "Please Enter Group Name\n";
    }
    if (grp.value.trim().length < 6) {
        msg = msg + "Group Name Must be Morethan 6 Characters\n"
    }
    if (grp != null && grp.value != "") {
        if (!grp.value.trim().match(special)) {
            msg = msg + "Special Characters are not allowed in Group Name \n";
        }
    }
    if (userName.value.trim() == "") {
        msg = msg + "Please Enter Group Owner Name\n";
    }
    if (msg == "")
        return true;
    else {
        alert(msg);
        return false;
    }
}
function ClearFields() {
    var grp = document.getElementById('<%=txtGrp.ClientID%>');
    var userName = document.getElementById('<%=txtGrpOwner.ClientID%>');
    grp.value = "";
    userName.value = "";
}
