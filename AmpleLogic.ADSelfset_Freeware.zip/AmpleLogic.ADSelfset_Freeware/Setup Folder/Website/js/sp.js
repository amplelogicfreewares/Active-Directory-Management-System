var L_EditDocumentProgIDError_Text = "'Edit Document' requires a Windows SharePoint Services-compatible application and Microsoft Internet Explorer 6.0 or greater."; var L_EditDocumentRuntimeError_Text = "The document could not be opened for editing.  A Windows SharePoint Services compatible application could not be found to edit the document."; var browseris = new Browseris();
function editDocumentWithProgID2(strDocument, varProgID, varEditor, bCheckout, strhttpRoot, strCheckouttolocal) {
    var errorCode = editDocumentWithProgIDNoUI(strDocument, varProgID, varEditor, bCheckout, strhttpRoot, strCheckouttolocal);
    if (errorCode == 1) {
        alert(L_EditDocumentRuntimeError_Text);
        window.onfocus = RefreshOnNextFocus;
    }
    else if (errorCode == 2) alert(L_EditDocumentProgIDError_Text);
}
function editDocumentWithProgIDNoUI(strDocument, varProgID, varEditor, bCheckout, strhttpRoot, strCheckouttolocal) {
    var objEditor;
    var fRet;
    var fUseLocalCopy = false;
    varEditor = varEditor.replace(/(?:\.\d+)$/, '');
    if (strDocument.charAt(0) == "/" || strDocument.substr(0, 3).toLowerCase() == "%2f")
        strDocument = document.location.protocol + "//" + document.location.host + strDocument;
    var strextension = SzExtension(unescapeProperly(strDocument));
    if (FSupportCheckoutToLocal(strextension)) {
        try {
            objEditor = new ActiveXObject(varEditor + ".3");
            if (objEditor != null) {
                if (bCheckout == "1") {
                    if (!objEditor.CheckoutDocumentPrompt(strDocument, true, varProgID)) return 1;
                }
                else {
                    if (strCheckouttolocal == "1")
                        fUseLocalCopy = true;
                    if (!objEditor.EditDocument3(window, strDocument, fUseLocalCopy, varProgID))
                        return 1;
                } var fRefreshOnNextFocus = false;
                fRefreshOnNextFocus = objEditor.PromptedOnLastOpen();
                if (fRefreshOnNextFocus) {
                    window.onfocus = RefreshOnNextFocus;
                }
                else {
                    SetWindowRefreshOnFocus();
                }
                return;
            }
        }
        catch (e) { }
    }
    if (bCheckout == "1") {
        if (confirm(L_ConfirmCheckout_Text)) NavigateToCheckinAspx(strhttpRoot, "FileName=" + escapeProperly(unescapeProperly(strDocument)) + "&Checkout=true");
        else
            return;
    }
    try {
        objEditor = new ActiveXObject(varEditor + ".2");
        if (!objEditor.EditDocument2(window, strDocument, varProgID))
            return 1;
        window.onfocus = RefreshOnNextFocus;
        return;
    }
    catch (e) { }
    try {
        objEditor = new ActiveXObject(varEditor + ".1");
        window.onfocus = null; 
        if (SzExtension(strDocument) == "ppt" && varProgID == "")
            varProgID = "PowerPoint.Slide";
        if (!objEditor.EditDocument(strDocument, varProgID))
            return 1;
        SetWindowRefreshOnFocus();
        return;
    }
    catch (e) {
        return 2; 
            }
}
 function RefreshOnNextFocus() { SetWindowRefreshOnFocus(); } function Browseris() { var agt = navigator.userAgent.toLowerCase(); this.osver = 1.0; if (agt) { var stOSVer = agt.substring(agt.indexOf("windows ") + 11); this.osver = parseFloat(stOSVer); } this.major = parseInt(navigator.appVersion); this.nav = ((agt.indexOf('mozilla') != -1) && ((agt.indexOf('spoofer') == -1) && (agt.indexOf('compatible') == -1))); this.nav6 = this.nav && (this.major == 5); this.nav6up = this.nav && (this.major >= 5); this.nav7up = false; if (this.nav6up) { var navIdx = agt.indexOf("netscape/"); if (navIdx >= 0) this.nav7up = parseInt(agt.substring(navIdx + 9)) >= 7; } this.ie = (agt.indexOf("msie") != -1); this.aol = this.ie && agt.indexOf(" aol ") != -1; if (this.ie) { var stIEVer = agt.substring(agt.indexOf("msie ") + 5); this.iever = parseInt(stIEVer); this.verIEFull = parseFloat(stIEVer); } else this.iever = 0; this.ie4up = this.ie && (this.major >= 4); this.ie5up = this.ie && (this.iever >= 5); this.ie55up = this.ie && (this.verIEFull >= 5.5); this.ie6up = this.ie && (this.iever >= 6); this.winnt = ((agt.indexOf("winnt") != -1) || (agt.indexOf("windows nt") != -1)); this.win32 = ((this.major >= 4) && (navigator.platform == "Win32")) || (agt.indexOf("win32") != -1) || (agt.indexOf("32bit") != -1); this.mac = (agt.indexOf("mac") != -1); this.w3c = this.nav6up; this.safari = (agt.indexOf("safari") != -1); this.safari125up = false; if (this.safari && this.major >= 5) { var navIdx = agt.indexOf("safari/"); if (navIdx >= 0) this.safari125up = parseInt(agt.substring(navIdx + 7)) >= 125; } } function unescapeProperlyInternal(str) { if (str == null) return "null"; var ix = 0, ixEntity = 0; var strResult = ""; var rgUTF8Bytes = new Array; var ixUTF8Bytes = 0; var hexString, hexCode; while (ix < str.length) { if (str.charAt(ix) == '%') { if (str.charAt(++ix) == 'u') { hexString = ""; for (ixEntity = 0; ixEntity < 4 && ix < str.length; ++ixEntity) { hexString += str.charAt(++ix); } while (hexString.length < 4) { hexString += '0'; } hexCode = parseInt(hexString, 16); if (isNaN(hexCode)) { strResult += '?'; } else { strResult += String.fromCharCode(hexCode); } } else { hexString = ""; for (ixEntity = 0; ixEntity < 2 && ix < str.length; ++ixEntity) { hexString += str.charAt(ix++); } while (hexString.length < 2) { hexString += '0'; } hexCode = parseInt(hexString, 16); if (isNaN(hexCode)) { if (ixUTF8Bytes) { strResult += Vutf8ToUnicode(rgUTF8Bytes); ixUTF8Bytes = 0; rgUTF8Bytes.length = ixUTF8Bytes; } strResult += '?'; } else { rgUTF8Bytes[ixUTF8Bytes++] = hexCode; } } } else { if (ixUTF8Bytes) { strResult += Vutf8ToUnicode(rgUTF8Bytes); ixUTF8Bytes = 0; rgUTF8Bytes.length = ixUTF8Bytes; } strResult += str.charAt(ix++); } } if (ixUTF8Bytes) { strResult += Vutf8ToUnicode(rgUTF8Bytes); ixUTF8Bytes = 0; rgUTF8Bytes.length = ixUTF8Bytes; } return strResult; } function unescapeProperly(str) { var strResult = null; if ((browseris.ie55up || browseris.nav6up) && (typeof (decodeURIComponent) != "undefined")) { strResult = decodeURIComponent(str); } else { strResult = unescapeProperlyInternal(str); } return strResult; } function SzExtension(szHref) { var sz = new String(szHref); var re = /^.*\.([^\.]*)$/; return sz.replace(re, "$1").toLowerCase(); } var g_ExtensionNotSupportCheckoutToLocal = new Array("ascx", "asp", "aspx", "htm", "html", "master", "odc", "exe", "bat", "com", "cmd", "onetoc2"); var g_ExtensionDefaultForRead = new Array("jpg", "jpeg", "bmp", "png", "gif", "onetoc2", "one", "odc"); function FSupportCheckoutToLocal(strExtension) { var fRet = true; if (strExtension == null || strExtension == "") return false; strExtension = strExtension.toLowerCase(); var ix = 0; for (ix = 0; ix < g_ExtensionNotSupportCheckoutToLocal.length; ix++) { if (strExtension == g_ExtensionNotSupportCheckoutToLocal[ix]) return false; } return true; } var g_varSkipRefreshOnFocus = 0; function RefreshOnFocus() { if (typeof (g_varSkipRefreshOnFocus) == "undefined" || !g_varSkipRefreshOnFocus) { var url = window.location.href; var iPosition = url.indexOf("#"); if (iPosition == -1) window.location.href = url; else window.location.href = url.substring(0, iPosition); } } function DisableRefreshOnFocus() { g_varSkipRefreshOnFocus = 1; } function SetWindowRefreshOnFocus() { window.onbeforeunload = DisableRefreshOnFocus; window.onfocus = RefreshOnFocus; }