﻿    var containerID = 'divStatus'  //Used to store the status of the output.
    var statusBarID = 'statusBar';  //Store the Status Bar Wrapper ID.
    var delimiter = "@";
    var inID = 'Button1';   //Store the input element ID.
    var outID = "TextBox1"; //Store the output element ID.
    var keywordStop = "Aborted";
    var fadeWrapper = "LoaderWrapper";
   //||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
   //Note:  Please the following:
   /*
        The received sequences from the .getExtraData()
        0. Percentage of being completed, unless there was an error, which an 
        "Aborted" value is received.
        1. Output of the result.
        2. The size of the original file.
        
   */
   //||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
    
    function OnProgress(progressBar)
    {
       
	        var extraData = progressBar.getExtraData();
	 
	   
	  
	  
	        if (extraData)
	        {
		        //The following code demonstrates how to update
		        //client side DHTML element based on the value
		        //RunTask passed to us with e.UpdateProgress
        		
        		
		        var result = extraData.split(delimiter);
		        var div = document.getElementById(containerID);
		        div.innerHTML = ""; //Flush out previous value.
    		    
    		    
		        if(result[0] == keywordStop)
		        {
		            div.innerHTML = "<span style='color: red; font-weight: bold;' >"+result[0]+"</span>";
		            document.getElementById(statusBarID).className = 'hide';    
    		        
		        }
		        else
		            div.innerHTML = "Completed&nbsp;"+result[0]+"&nbsp;of&nbsp;" + result[2];
        		
		        if(result[0] == result[2])  //Reached 100 and now it can be hidden...
		            document.getElementById(statusBarID).className = 'hide';    
        		
    		    //Error message Sections....
		        if(result[1].length > 5)    
		        {   
		            try
		            {
		                document.getElementById(outID).value = result[1];
		            }
		            catch(err)
		            {
		                alert(err.description);		            
		            }
		            document.getElementById(statusBarID).className = 'hide';    
		        }
    		
	        }
	  
	    
	    
        
	    
	    
	  
	    
    }


   Event.observe(window, 'load', function()     
    /*------------------------------------------------------------------
    Precondition: None.
    Postcondition: Appending Body Onload Event.
    ------------------------------------------------------------------*/
    {   
      //Now it only has read only attribute.
        
        
        //Adding click event to 
        Event.observe(inID, 'click', function(event) {
              
            show(statusBarID); 
                   
        });
        
      
      
     
    });
    
  function show(ID)
  {
    //alert("reading from file ...SHowing..."+ID)    //DEBUG...
    var obj = document.getElementById(ID);
    obj.className = "progressbar";
    pageCover(fadeWrapper)
    
    
  }
  
  function disable()    //Would receive ID, but it buggy with EO.NET Framework
  {
    var ID = inID;
    var obj = document.getElementById(ID);
    
    //alert(document.getElementById(outID).value.length);
    if(document.getElementById(outID).value.length != 0)
    {   
        obj.disabled = true;
    }
    else
    {   
        obj.disabled = false;
    }
    
    //Use for Loading Statuses.
    document.getElementById(fadeWrapper).className = 'hide'; 
    document.getElementById(statusBarID).className = 'hide';    
        
  }
  
  function pageCover(ID)
    {
        
        
      
        
        var winWidth = 0, winHeight = 0;
      if( typeof( window.innerWidth ) == 'number' ) {
        //Non-IE
        winWidth = window.innerWidth;
        winHeight = window.innerHeight;
      } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
        //IE 6+ in 'standards compliant mode'
        winWidth = document.documentElement.clientWidth;
        winHeight = document.documentElement.clientHeight;
      } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
        //IE 4 compatible
        winWidth = document.body.clientWidth;
        winHeight = document.body.clientHeight;
      }
      

        var dimension = getScrollXY();
        
      
        document.getElementById(ID).style.width = winWidth + dimension[0];
        document.getElementById(ID).style.height = winHeight + dimension[1];
        
        
        document.getElementById(ID).className = 'fade';   
        
        
        
        
    }
    
    
    function getScrollXY()     
    /*-----------------------------------------------------------------------------------
    Precondition: None.
    Postcondition: Return the offset for x and y width.
    URL: http://www.howtocreate.co.uk/tutorials/javascript/browserwindow
    -----------------------------------------------------------------------------------*/
    {
      var scrOfX = 0, scrOfY = 0;
      if( typeof( window.pageYOffset ) == 'number' ) {
        //Netscape compliant
        scrOfY = window.pageYOffset;
        scrOfX = window.pageXOffset;
      } else if( document.body && ( document.body.scrollLeft || document.body.scrollTop ) ) {
        //DOM compliant
        scrOfY = document.body.scrollTop;
        scrOfX = document.body.scrollLeft;
      } else if( document.documentElement && ( document.documentElement.scrollLeft || document.documentElement.scrollTop ) ) {
        //IE6 standards compliant mode
        scrOfY = document.documentElement.scrollTop;
        scrOfX = document.documentElement.scrollLeft;
  }
  return [ scrOfX, scrOfY ];
}
  