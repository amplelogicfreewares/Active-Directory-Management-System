﻿// Asynchronous file upload process
function ajaxFileUpload() {
    try {
        //Get Folder path to save the uploaded document
        var fileFolder = $('#hdnFileFolder').val();

        //get File details to be uploaded
        var fileToUpload = GetNameFromPath($('#fileToUpload').val());

        //get The file name
        var fileName = fileToUpload.substr(0, (fileToUpload.lastIndexOf('.')));

        //Check for the extension of the file uploaded
        //If the return value is true
        if (CheckFileExtension(fileToUpload)) {

            var flag = true;
            var counter = $('#hdnCountFiles').val(); //Stores no.of files uploaded

            if (fileName != "" && fileName != null && fileFolder != "0") {
                //Check duplicate file entry
                for (var i = 1; i <= counter; i++) {
                    var hdnDocId = "#hdnDocId_" + i;

                    if ($(hdnDocId).length > 0) {
                        var mFileName = "#lblfilename_" + i;
                        if ($(mFileName).html() == fileName) {
                            flag = false;
                            break;
                        }

                    }
                }
                //If the file didn't exist, uploading the file
                if (flag == true) {
                    //showing loading image while processing the upload, and after completion hiding that image
                    $("#loading").ajaxStart(function () {
                        $(this).show();
                    }).ajaxComplete(function () {
                        $(this).hide();
                        return false;
                    });

                    //Uploads file to folder
                    $.ajaxFileUpload({
                        url: 'VS_FileUpload.ashx?id=' + fileFolder,
                        secureuri: false,
                        fileElementId: 'fileToUpload',
                        dataType: 'json',
                        success: function (data, status) {

                            if (typeof (data.error) != 'undefined') {
                                if (data.error != '') {
                                    alert(data.error);
                                } else {
                                    ShowUploadedFiles(data.timestamp, fileName);
                                    $('#fileToUpload').val("");
                                }
                            }
                        },
                        error: function (data, status, e) {
                            alert(e);
                        }
                    });
                }
                else {
                    alert('file ' + fileName + ' already exists')
                    return false;
                }
            }
        }
        else {
            alert('You can upload only jpg,jpeg,gif and png extension files.');
        }
        return false;
    }
    catch (e) {
        console.log(e);
    }
}

//show uploaded file 
function ShowUploadedFiles(file, fileName) {
    try {
        count = parseInt($("#hdnCountFiles").val()) + 1;
        var hdnId = 'hdnDocId_' + count;
        var txtDocDescId = 'txtDocDesc_' + count;

        // Stores the folder path that contains uploaded files    
        var folderPath = $('#hdnUploadFolderPath').val();

        // Stores the path of attachment
        var filePath = $('#hdnUploadFilePath').val();

        //Get Document name FieldId
        var docNameAtrrID = $('#hdnDocNameAttrId').val();

        //Get DocumentPath FieldId
        var docPathAttrID = $('#hdnDocPathAttrId').val();

        //Get File Extension
        var fileExtn = file.substr((file.lastIndexOf('.') + 1));

        var dpath = folderPath.split('\\');
        dpath = dpath.join('\\\\');

        $("#dvUploadedDocs").append("<div active='1' formId='0' style='float:left;padding:20px 20px 0px 20px;' id='" + hdnId + "'>" +
                                      "<span class='DownloadAttachment'>" +
                                           "<a atrributeid='" + docNameAtrrID + "' attributevalue='" + fileName + "' class='dellink' href='VS_FileUpload.ashx?filepath=" + folderPath + "&file=" + file + "'></a>" +
                                      "</span>" +
                                      "<span style='padding-left:5px' class='DeleteAttachment'>" +
                                            "<a href='#' class='dellink' onclick='DeleteAttachment(\"#" + hdnId + "," + file + "," + dpath + "\")'>Cancel</a>" +
                                      "</span>" +
        //                                      "<span class='ViewAttachment'>" +
        //                                            "<a class='dellink' href='../../" + filePath + "/" + file + "' data-lightbox='image' atrributeid='" + docPathAttrID + "' attributevalue='../" + filePath + "/" + file + "' ><img src='../Images/view_attachment.png' height='20px' width='20px' title='View'/></a>" +
        //                                      "</span>" +
                              "</div>");


        //update file counter
        //<img src='../Images/delete_attachment.png' height='20px' width='20px' title='Delete' />
        $("#hdnCountFiles").val(count);
        if (count > 0) {
            $('#divFileUpload').hide();

            $('#imgProfile1').attr('src', "../" + filePath + file);
            $('#hdnFilePath').val(filePath + file);
        }
        return false;
    }
    catch (e) {
        console.log(e);
    }
}

//Deleting an attachments
function DeleteAttachment(divrow) {
    try {
        var strElement = divrow.split(",");
        var attachmentDivId = strElement[0];

        //Show Confirmation message to user before deleting document
        if (confirm('Are you sure to delete this attachment?')) {

            //set attachment div id active property as '0'
            $(attachmentDivId).attr('active', 0);

            //Hide that attachments div(To Send it as Inactive record to Database)
            $(attachmentDivId).remove();
            $('#imgProfile1').removeAttr('src');
            $('#imgProfile1').attr('src', $('#hdnOldPath').val());
            $('#hdnFilePath').val("");
            $('#divFileUpload').show();
        }
        return false;
    }
    catch (e) {
        console.log(e);
    }
}

// check extension of file to be upload
function CheckFileExtension(file) {
    try {
        var flag = true;

        //Get Uploaded File Extension
        var extension = file.substr((file.lastIndexOf('.') + 1));

        //If the uploaded file extension is any of following type
        switch (extension.toLowerCase()) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
                //Set the flag to true
                flag = true;
                break;
            default:
                //Set the flag to false
                flag = false;
        }
        //returns flag value
        return flag;
    }
    catch (e) {
        console.log(e);
    }
}
//Returns file path from client system
function GetNameFromPath(strFilepath) {
    try {
        var objRE = new RegExp(/([^\/\\]+)$/);
        var strName = objRE.exec(strFilepath);

        if (strName == null) {
            return null;
        }
        else {
            return strName[0];
        }
    }
    catch (e) {
        console.log(e);
    }

}