﻿function CompareDates(date1, date2) {
    var blnEarlier = true;   

    var vD1_Year = date1.substr(6, 4);
    var vD2_Year = date2.substr(6, 4);

    var vD1_Month = date1.substr(3, 2);
    var vD2_Month = date2.substr(3, 2);

    var vD1_Day = date1.substr(0, 2);
    var vD2_Day = date2.substr(0, 2);

    if (vD1_Year < vD2_Year)    //compare year
        blnEarlier = true;
    else if (vD1_Year > vD2_Year)
        blnEarlier = false;
    else
        if (vD1_Month < vD2_Month)    //compare month
            blnEarlier = true;
        else if (vD1_Month > vD2_Month)
            blnEarlier = false;
        else
            if (vD1_Day < vD2_Day)    //compare day
                blnEarlier = true;
            else
                blnEarlier = false;

    //if two dates are same then returns true
    if (vD1_Year == vD2_Year && vD1_Month == vD2_Month && vD1_Day == vD2_Day) {
        blnEarlier = true;
    }


    return (blnEarlier);
} 